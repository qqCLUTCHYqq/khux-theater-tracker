Cross Road Windows desktop package 2.1.0 - LOCAL PREVIEW, NOT PUBLISHED

Fresh setup: extract all files, run START SETUP.cmd. Installed Google Chrome or
Microsoft Edge is required; setup does not install a browser. The verified 2.0.1
content downloader is retained. Choose Open Cross Road, then Play game when ready.

Existing 2.0.1 installations: use the separate CrossRoad-Updater-Bootstrap.zip and
ADD UPDATER.cmd. Choose the existing installation containing v1 and Content.
Do not choose a new directory or copy/move your browser profile. The bootstrap
adds only Setup/Updater support files and an updater shortcut. It never launches
the game, alters saved progress, or overwrites Content or v1/index.html.

Inside the desktop panel: Check for updates -> read release details -> close
the game -> Update. Current stable public release 2.0.1 is not updater-compatible;
the local preview is waiting for an approved release publication. No audio
candidate, game content, browser binaries, saves, credentials or services are
included. Existing browser-choice.json and profile paths remain intact.

See App/Updater/README.txt for integrity, full-profile backup and rollback details.