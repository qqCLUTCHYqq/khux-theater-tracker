# Cross Road desktop updater 2.1.0. No game/browser/profile commands are executed here.
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$script:Repository = 'qqCLUTCHYqq/khux-theater-tracker'
$script:ReleaseApi = 'https://api.github.com/repos/' + $script:Repository + '/releases/latest'
$script:UpdaterFiles = @('Core.ps1','UI.ps1','Browser.ps1','version.json','README.txt')
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.IO.Compression

function Get-NativePath([string]$Path) { if($Path.StartsWith('\\?\')){return $Path};'\\?\'+[IO.Path]::GetFullPath($Path) }
function Get-Sha([string]$Path) { (Get-FileHash -LiteralPath (Get-NativePath $Path) -Algorithm SHA256).Hash.ToLowerInvariant() }
function Copy-LongFile([string]$LiteralPath,[string]$Destination,[switch]$Force) {
    Assert-NoLinks $LiteralPath;Assert-NoLinks $Destination
    $target=Get-NativePath $Destination
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))|Out-Null
    [IO.File]::Copy((Get-NativePath $LiteralPath),$target,[bool]$Force)
}
function Get-VersionNumber([string]$Text) {
    if ($Text -notmatch '^v?(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$') { throw 'Unsupported release version.' }
    [version]($Text.TrimStart('v'))
}
function Assert-NoLinks([string]$Path) {
    $p=[IO.Path]::GetFullPath($Path)
    while ($p) {
        $native=Get-NativePath $p
        if ([IO.File]::Exists($native) -or [IO.Directory]::Exists($native)) {
            if ([IO.File]::GetAttributes($native) -band [IO.FileAttributes]::ReparsePoint) { throw "Linked paths are not supported: $p" }
        }
        $parent=[IO.Path]::GetDirectoryName($p.TrimEnd('\'))
        if ($parent -eq $p) { break }; $p=$parent
    }
}
function Get-SafePath([string]$Root,[string]$Relative) {
    if (!$Relative -or [IO.Path]::IsPathRooted($Relative) -or $Relative.Contains('\') -or $Relative -match '[\x00-\x1f\x7f:"<>|?*]' -or $Relative.Contains('//')) { throw 'Unexpected package path.' }
    foreach($part in $Relative.Split('/')) {
        if (!$part -or $part -eq '.' -or $part -eq '..' -or $part.EndsWith('.') -or $part.EndsWith(' ') -or $part -match '^(?i:CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\.|$)') { throw 'Unexpected package path.' }
    }
    $base=[IO.Path]::GetFullPath($Root).TrimEnd('\')+'\'
    $path=[IO.Path]::GetFullPath((Join-Path $base $Relative.Replace('/','\')))
    if (!$path.StartsWith($base,[StringComparison]::OrdinalIgnoreCase)) { throw 'Path leaves its expected directory.' }
    Assert-NoLinks $path; $path
}
function Get-ManagerRoot([string]$Root) {
    $r=[IO.Path]::GetFullPath($Root).TrimEnd('\')
    if ($r -eq [IO.Path]::GetPathRoot($r).TrimEnd('\') -or $r.StartsWith('\\')) { throw 'Choose a local game installation folder.' }
    Assert-NoLinks $r
    if (!(Test-Path -LiteralPath (Join-Path $r 'v1\index.html') -PathType Leaf)) { throw 'This folder is not an installed Cross Road game.' }
    $r
}
function Write-AtomicJson([string]$Path,$Value) {
    Assert-NoLinks $Path
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Path)) | Out-Null
    $tmp=$Path+'.new-'+[Guid]::NewGuid().ToString('N')
    [IO.File]::WriteAllText($tmp,($Value|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
    if(Test-Path -LiteralPath $Path){$previous=$Path+'.atomic-old-'+[Guid]::NewGuid().ToString('N');[IO.File]::Replace($tmp,$Path,$previous);[IO.File]::Delete($previous)}else{[IO.File]::Move($tmp,$Path)}
}
function Read-State([string]$Root) {
    $path=Join-Path $Root 'Setup\Updater\active.json'
    if (!(Test-Path -LiteralPath $path)) { throw 'Install the updater bootstrap once before checking updates.' }
    $s=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if($s.application -ne 'cross-road-windows' -or $s.schema -ne 1){throw 'Invalid installed updater receipt.'}
    $files=@($s.files);if($files.Count -ne 5){throw 'Incomplete installed updater receipt.'};$seen=@{}
    foreach($f in $files){if($f.path -cnotin $script:UpdaterFiles -or $seen.ContainsKey($f.path) -or $f.sha256 -notmatch '^[0-9a-f]{64}$'){throw 'Invalid installed app ownership receipt.'};$seen[$f.path]=$true}
    Get-VersionNumber $s.version | Out-Null; $s
}
function Assert-ReleaseUrl([string]$Url,[string]$Version,[string]$Name) {
    $expected='https://github.com/'+$script:Repository+'/releases/download/v'+(Get-VersionNumber $Version).ToString(3)+'/'+$Name
    if($Url -cne $expected){throw 'Release asset URL does not belong to the trusted repository and version.'}
}
function Get-ReleaseAsset($Release,[string]$Name) {
    $items=@($Release.assets|Where-Object {$_.name -ceq $Name})
    if($items.Count -ne 1){throw "Release does not contain exactly one $Name asset."}
    $a=$items[0]
    Assert-ReleaseUrl $a.browser_download_url $Release.tag_name $Name
    if($a.state -ne 'uploaded' -or $a.digest -notmatch '^sha256:([0-9a-fA-F]{64})$' -or [long]$a.size -le 0){throw 'Release asset is missing verified SHA256 metadata.'}
    $a
}
function Receive-TrustedFile([string]$Url,[string]$Destination,[long]$Limit,[scriptblock]$Progress) {
    # Redirects are followed only to GitHub's release CDN. No credentials or certificate exceptions.
    $u=[uri]$Url
    $hosts=@('api.github.com','github.com','release-assets.githubusercontent.com','objects.githubusercontent.com')
    for($redirect=0;$redirect -le 5;$redirect++){
        if($u.Scheme -ne 'https' -or $u.Port -ne 443 -or $u.UserInfo -or $u.Host -notin $hosts){throw 'Untrusted download destination.'}
        $request=[Net.HttpWebRequest]::Create($u);$request.AllowAutoRedirect=$false;$request.Timeout=30000;$request.ReadWriteTimeout=30000;$request.UserAgent='CrossRoad-Updater/2.1.0';$request.Accept='application/vnd.github+json'
        $response=$request.GetResponse()
        try {
            $code=[int]$response.StatusCode
            if($code -in @(301,302,303,307,308)){
                $next=$response.Headers['Location'];if(!$next){throw 'Missing release redirect.'};$u=[uri]::new($u,$next);continue
            }
            if($code -ne 200 -or $response.ContentLength -gt $Limit){throw 'Unexpected download response or oversized asset.'}
            $input=$response.GetResponseStream();$output=[IO.File]::Open($Destination,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::None)
            try{$buffer=New-Object byte[] 65536;$total=0L;while(($n=$input.Read($buffer,0,$buffer.Length)) -gt 0){$total+=$n;if($total -gt $Limit){throw 'Download exceeds its permitted size.'};$output.Write($buffer,0,$n);if($Progress){& $Progress "Downloading update: $([Math]::Round($total/1KB)) KB"}}}finally{$output.Dispose();$input.Dispose()}
            return
        } finally {$response.Dispose()}
    }
    throw 'Too many release redirects.'
}
function Get-LatestRelease([string]$Root,[scriptblock]$Transport) {
    $state=Read-State $Root
    if($Transport){$r=& $Transport $script:ReleaseApi}else{
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        $r=Invoke-RestMethod -Uri $script:ReleaseApi -UserAgent 'CrossRoad-Updater/2.1.0' -TimeoutSec 30
    }
    if($r.draft -or $r.prerelease){throw 'Only published stable releases are supported.'}
    $version=Get-VersionNumber $r.tag_name
    if($r.html_url -cne ('https://github.com/'+$script:Repository+'/releases/tag/v'+$version.ToString(3))){throw 'Unexpected release source.'}
    $compatible=(@($r.assets|Where-Object {$_.name -ceq 'CrossRoad-Update.json'}).Count -eq 1 -and @($r.assets|Where-Object {$_.name -ceq 'CrossRoad-Update.zip'}).Count -eq 1)
    if($compatible){Get-ReleaseAsset $r 'CrossRoad-Update.json'|Out-Null;Get-ReleaseAsset $r 'CrossRoad-Update.zip'|Out-Null}
    [pscustomobject]@{Current=$state.version;Version=$version.ToString(3);Available=($version -gt (Get-VersionNumber $state.version) -and $compatible);Compatible=$compatible;Url=$r.html_url;Notes=([string]$r.body).Substring(0,[Math]::Min(8192,([string]$r.body).Length));Release=$r}
}
function Assert-NotRunning([string]$Root,[scriptblock]$Processes) {
    if($Processes){$list=@(& $Processes)}else{try{$list=@(Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {$_.Name -in @('chrome.exe','msedge.exe')})}catch{throw 'Windows could not verify whether the game is running. Update has not started.'}}
    $profiles=@((Join-Path $Root 'GameProfile'),(Join-Path $Root 'EdgeGameProfile'))
    foreach($p in $list){
        if(!$p.CommandLine){throw 'A browser process cannot be inspected safely. Update has not started.'}
        foreach($m in [regex]::Matches($p.CommandLine,'(?i)--user-data-dir(?:=|\s+)(?:"([^"]+)"|([^\s"]+))')){
            $dir=if($m.Groups[1].Success){$m.Groups[1].Value}else{$m.Groups[2].Value}
            foreach($profile in $profiles){if([IO.Path]::GetFullPath($dir).TrimEnd('\') -ieq [IO.Path]::GetFullPath($profile).TrimEnd('\')){throw 'Close the Cross Road game window before updating. Your personal browser windows can stay open.'}}
        }
    }
}
function Get-TreeReceipt([string]$Root) {
    $items=@()
    foreach($name in @('GameProfile','EdgeGameProfile','Content')){
        $folder=Join-Path $Root $name
        if(Test-Path -LiteralPath $folder){Assert-NoLinks $folder;foreach($f in Get-ChildItem -LiteralPath (Get-NativePath $folder) -Recurse -File -Force){$logical=$f.FullName;if($logical.StartsWith('\\?\')){$logical=$logical.Substring(4)};Assert-NoLinks $logical;$items+= [pscustomobject]@{path=$logical.Substring($Root.Length+1).Replace('\','/');size=$f.Length;sha256=Get-Sha $logical}}}
    }
    $items
}
function Assert-ReceiptUnchanged([string]$Root,$Receipt) {
    $now=@(Get-TreeReceipt $Root)
    if($now.Count -ne @($Receipt).Count){throw 'Protected game data changed while updating; recovery required.'}
    foreach($f in $Receipt){$match=@($now|Where-Object {$_.path -ceq $f.path});if($match.Count -ne 1 -or $match[0].sha256 -cne $f.sha256){throw 'Protected game data changed while updating; recovery required.'}}
}
function Assert-Manifest($Manifest,$Offer) {
    if($Manifest.application -ne 'cross-road-windows' -or $Manifest.schema -ne 1 -or $Manifest.version -cne $Offer.Version){throw 'Update manifest identity or version mismatch.'}
    if((Get-VersionNumber $Manifest.version) -le (Get-VersionNumber $Offer.Current)){throw 'Downgrades and same-version replacement are not supported.'}
    $files=@($Manifest.files);if($files.Count -lt 5 -or $files.Count -gt 6){throw 'Unexpected update file count.'}
    $seen=@{}
    foreach($f in $files){
        $allowed=($f.path -ceq 'Runtime/index.html') -or ($f.path.StartsWith('Updater/') -and $f.path.Substring(8) -cin $script:UpdaterFiles)
        if(!$allowed -or $seen.ContainsKey($f.path.ToLowerInvariant())){throw 'Unexpected or duplicate update path.'};$seen[$f.path.ToLowerInvariant()]=$true
        Get-SafePath ([IO.Path]::GetTempPath()) $f.path | Out-Null
        if($f.sha256 -notmatch '^[0-9a-f]{64}$' -or [long]$f.size -le 0 -or [long]$f.size -gt 64MB){throw 'Invalid update file integrity metadata.'}
        if($f.path -ceq 'Runtime/index.html' -and ($Manifest.saveSchemaCompatible -isnot [bool] -or !$Manifest.saveSchemaCompatible -or @($f.fromSha256).Count -eq 0)){throw 'Runtime update has no save-compatible migration contract.'}
    }
    foreach($name in $script:UpdaterFiles){if(!$seen.ContainsKey(('Updater/'+$name).ToLowerInvariant())){throw 'Required updater file missing.'}}
}
function Expand-VerifiedUpdate([string]$Zip,[string]$Stage,$Manifest) {
    $archive=[IO.Compression.ZipFile]::OpenRead($Zip)
    try{
        $entries=@($archive.Entries);if($entries.Count -ne @($Manifest.files).Count){throw 'Unexpected ZIP entries.'}
        $seen=@{};$total=0L
        foreach($entry in $entries){
            $target=Get-SafePath $Stage $entry.FullName
            $key=$entry.FullName.ToLowerInvariant();if($seen.ContainsKey($key)){throw 'Duplicate ZIP path.'};$seen[$key]=$true
            if(($entry.ExternalAttributes -shr 16 -band 61440) -eq 40960){throw 'ZIP links are not supported.'}
            $f=@($Manifest.files|Where-Object {$_.path -ceq $entry.FullName})
            if($f.Count -ne 1 -or $entry.Length -ne [long]$f[0].size){throw 'ZIP path or size does not match the manifest.'}
            $total+=$entry.Length;if($total -gt 128MB){throw 'Expanded update exceeds its size limit.'}
        }
        foreach($entry in $entries){$target=Get-SafePath $Stage $entry.FullName;[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))|Out-Null;[IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$target,$false);$f=@($Manifest.files|Where-Object {$_.path -ceq $entry.FullName})[0];if((Get-Sha $target) -cne $f.sha256){throw 'Expanded file checksum mismatch.'}}
        $info=Get-Content -LiteralPath (Join-Path $Stage 'Updater\version.json') -Raw|ConvertFrom-Json
        if($info.application -ne 'cross-road-windows' -or $info.schema -ne 1 -or $info.version -cne $Manifest.version){throw 'Payload version receipt does not match the release.'}
    }finally{$archive.Dispose()}
}
function Restore-Transaction([string]$Root,$Journal) {
    $manager=Join-Path $Root 'Setup\Updater'
    $backup=Get-SafePath $manager ('Backups/'+$Journal.id)
    $old=Get-Content -LiteralPath (Join-Path $backup 'active.json') -Raw | ConvertFrom-Json
    Get-VersionNumber $Journal.toVersion|Out-Null;Get-VersionNumber $old.version|Out-Null
    if($old.version -cne $Journal.fromVersion -or $old.application -ne 'cross-road-windows' -or $old.schema -ne 1){throw 'Recovery receipt does not match the pending transaction.'}
    $oldDir=Get-SafePath $manager ('Versions/'+$old.version);[IO.Directory]::CreateDirectory($oldDir)|Out-Null
    foreach($f in $old.files){if($f.path -cnotin $script:UpdaterFiles){throw 'Invalid backup file ownership.'};$saved=Get-SafePath $backup ('Updater/'+$f.path);if(!(Test-Path -LiteralPath $saved) -or (Get-Sha $saved) -cne $f.sha256){throw 'App backup checksum mismatch.'};Copy-LongFile -LiteralPath $saved -Destination (Get-SafePath $oldDir $f.path) -Force}
    $runtime=Join-Path $backup 'index.html'
    if($Journal.runtimeChanged){if(!(Test-Path -LiteralPath $runtime) -or (Get-Sha $runtime) -cne $Journal.oldRuntimeSha){throw 'Runtime backup is incomplete; do not launch the game.'};Copy-LongFile -LiteralPath $runtime -Destination (Join-Path $Root 'v1\index.html') -Force}
    Write-AtomicJson (Join-Path $manager 'active.json') $old
    $unused=Get-SafePath $manager ('Versions/'+$Journal.toVersion)
    if(Test-Path -LiteralPath $unused){$quarantine=Get-SafePath $manager ('Quarantine/'+$Journal.id+'-'+$Journal.toVersion);[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($quarantine))|Out-Null;Move-Item -LiteralPath $unused -Destination $quarantine}
    Write-AtomicJson (Join-Path $manager 'journal.json') @{schema=1;status='rolled-back';id=$Journal.id;fromVersion=$Journal.fromVersion;toVersion=$Journal.toVersion;runtimeChanged=$Journal.runtimeChanged;oldRuntimeSha=$Journal.oldRuntimeSha}
}
function Repair-PendingUpdate([string]$Root,[scriptblock]$Processes,[switch]$LockHeld) {
    $Root=Get-ManagerRoot $Root;$path=Join-Path $Root 'Setup\Updater\journal.json'
    $lock=$null
    try{if(!$LockHeld){$lock=[IO.File]::Open((Join-Path $Root 'Setup\Updater\update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)};if(Test-Path -LiteralPath $path){$j=Get-Content -LiteralPath $path -Raw|ConvertFrom-Json;if($j.status -eq 'pending'){Assert-NotRunning $Root $Processes;Restore-Transaction $Root $j;return $true}};$false}finally{if($lock){$lock.Dispose()}}
}
function Invoke-PreparedUpdate([string]$Root,$Offer,$Manifest,[string]$Zip,[scriptblock]$Processes,[scriptblock]$Progress,[scriptblock]$Fault) {
    $Root=Get-ManagerRoot $Root;Assert-Manifest $Manifest $Offer
    $manager=Join-Path $Root 'Setup\Updater';Assert-NoLinks $manager
    $lock=[IO.File]::Open((Join-Path $manager 'update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $journal=$null
    try{
        Repair-PendingUpdate $Root $Processes -LockHeld|Out-Null
        $current=Read-State $Root;if($current.version -cne $Offer.Current){throw 'Installed version changed. Check for updates again.'}
        Assert-NotRunning $Root $Processes
        $id=(Get-Date -Format 'yyyyMMddTHHmmss')+'-'+[Guid]::NewGuid().ToString('N')
        $stage=Get-SafePath $manager ('Staging/'+$id);[IO.Directory]::CreateDirectory($stage)|Out-Null
        Expand-VerifiedUpdate $Zip $stage $Manifest
        $runtime=@($Manifest.files|Where-Object {$_.path -ceq 'Runtime/index.html'})
        $oldSha=Get-Sha (Join-Path $Root 'v1\index.html')
        if($runtime.Count -and $oldSha -cnotin @($runtime[0].fromSha256)){throw 'Your existing game runtime is modified or unsupported. It has been preserved.'}
        $newVersion=Get-SafePath $manager ('Versions/'+$Manifest.version)
        if(Test-Path -LiteralPath $newVersion){throw 'This version directory already exists. No files were replaced.'}
        if($Progress){& $Progress 'Checking protected content and creating a save/profile backup...'}
        $protected=@(Get-TreeReceipt $Root)
        $backup=Get-SafePath $manager ('Backups/'+$id);[IO.Directory]::CreateDirectory($backup)|Out-Null
        $required=[long](($protected|Where-Object {$_.path -notlike 'Content/*'}|Measure-Object size -Sum).Sum)+128MB
        if([IO.DriveInfo]::new([IO.Path]::GetPathRoot($Root)).AvailableFreeSpace -lt $required){throw 'Not enough space for the full save/profile backup. Free space and try again.'}
        Copy-LongFile -LiteralPath (Join-Path $manager 'active.json') -Destination (Join-Path $backup 'active.json')
        $oldDir=Get-SafePath $manager ('Versions/'+$current.version)
        foreach($f in $current.files){if($f.path -cnotin $script:UpdaterFiles){throw 'Unknown installed app file.'};$src=Get-SafePath $oldDir $f.path;if((Get-Sha $src) -cne $f.sha256){throw 'Installed app was modified; update has not started.'};$saved=Get-SafePath $backup ('Updater/'+$f.path);[IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($saved))|Out-Null;Copy-LongFile -LiteralPath $src -Destination $saved;if((Get-Sha $saved) -cne $f.sha256){throw 'App backup verification failed.'}}
        Copy-LongFile -LiteralPath (Join-Path $Root 'v1\index.html') -Destination (Join-Path $backup 'index.html')
        foreach($f in $protected|Where-Object {$_.path -notlike 'Content/*'}){$from=Get-SafePath $Root $f.path;$to=Get-SafePath $backup $f.path;Copy-LongFile -LiteralPath $from -Destination $to;if((Get-Sha $to) -cne $f.sha256){throw 'Backup verification failed.'}}
        foreach($name in @('browser-choice.json','Launch-KHUX.ps1','Play KINGDOM HEARTS.cmd')){if(Test-Path -LiteralPath (Join-Path $Root $name)){Copy-LongFile -LiteralPath (Join-Path $Root $name) -Destination (Join-Path $backup $name)}}
        Write-AtomicJson (Join-Path $backup 'protected-content.json') $protected
        Assert-ReceiptUnchanged $Root $protected;Assert-NotRunning $Root $Processes
        $journal=@{schema=1;status='pending';id=$id;fromVersion=$current.version;toVersion=$Manifest.version;runtimeChanged=($runtime.Count -gt 0);oldRuntimeSha=$oldSha}
        Write-AtomicJson (Join-Path $manager 'journal.json') $journal
        if($Fault){& $Fault 'after-journal'}
        [IO.Directory]::CreateDirectory($newVersion)|Out-Null
        $newFiles=@()
        foreach($name in $script:UpdaterFiles){$src=Get-SafePath $stage ('Updater/'+$name);$dst=Get-SafePath $newVersion $name;Copy-LongFile -LiteralPath $src -Destination $dst;$f=@($Manifest.files|Where-Object {$_.path -ceq ('Updater/'+$name)})[0];if((Get-Sha $dst) -cne $f.sha256){throw 'Published updater file checksum mismatch.'};$newFiles+=@{path=$name;sha256=$f.sha256;size=$f.size}}
        if($Fault){& $Fault 'after-files'}
        Assert-NotRunning $Root $Processes
        if($runtime.Count){Copy-LongFile -LiteralPath (Join-Path $stage 'Runtime\index.html') -Destination (Join-Path $Root 'v1\index.html') -Force;if((Get-Sha (Join-Path $Root 'v1\index.html')) -cne $runtime[0].sha256){throw 'Runtime publication checksum mismatch.'}}
        if($Fault){& $Fault 'after-runtime'}
        Assert-ReceiptUnchanged $Root $protected
        Write-AtomicJson (Join-Path $manager 'active.json') @{schema=1;application='cross-road-windows';version=$Manifest.version;files=$newFiles;installed=(Get-Date).ToUniversalTime().ToString('o')}
        if($Fault){& $Fault 'after-pointer'}
        $journal.status='complete';Write-AtomicJson (Join-Path $manager 'journal.json') $journal
        if($Progress){& $Progress 'Update installed. Reopen the launcher to use the new version. Saves and content are unchanged.'}
        [pscustomobject]@{Version=$Manifest.version;Backup=$backup;ProfilesUntouched=$true;ContentUntouched=$true}
    }catch{if($journal){Restore-Transaction $Root $journal};throw}finally{$lock.Dispose()}
}
function Install-ReleaseUpdate([string]$Root,$Offer,[scriptblock]$Processes,[scriptblock]$Progress,[scriptblock]$DownloadTransport) {
    if(!$Offer.Available){throw 'No newer compatible update is available.'}
    $manifestAsset=Get-ReleaseAsset $Offer.Release 'CrossRoad-Update.json';$zipAsset=Get-ReleaseAsset $Offer.Release 'CrossRoad-Update.zip'
    if([long]$manifestAsset.size -gt 64KB -or [long]$zipAsset.size -gt 64MB){throw 'Release asset exceeds its size limit.'}
    $cache=Get-SafePath (Join-Path $Root 'Setup\Updater') ('Downloads/'+$Offer.Version);[IO.Directory]::CreateDirectory($cache)|Out-Null
    $paths=@{}
    foreach($asset in @($manifestAsset,$zipAsset)){
        $target=Join-Path $cache $asset.name;$sha=$asset.digest.Substring(7).ToLowerInvariant()
        if(!(Test-Path -LiteralPath $target) -or (Get-Sha $target) -cne $sha){$partial=$target+'.partial';if($DownloadTransport){& $DownloadTransport $asset.browser_download_url $partial ([long]$asset.size) $Progress}else{Receive-TrustedFile $asset.browser_download_url $partial ([long]$asset.size) $Progress};if((Get-Item -LiteralPath $partial).Length -ne [long]$asset.size -or (Get-Sha $partial) -cne $sha){throw 'Downloaded update failed its size or SHA256 check. Existing app and saves are untouched.'};Move-Item -LiteralPath $partial -Destination $target -Force}
        $paths[$asset.name]=$target
    }
    $manifest=Get-Content -LiteralPath $paths['CrossRoad-Update.json'] -Raw|ConvertFrom-Json
    Invoke-PreparedUpdate $Root $Offer $manifest $paths['CrossRoad-Update.zip'] $Processes $Progress
}
function Restore-PreviousUpdate([string]$Root,[scriptblock]$Processes) {
    $Root=Get-ManagerRoot $Root;Assert-NotRunning $Root $Processes
    $manager=Join-Path $Root 'Setup\Updater';$lock=[IO.File]::Open((Join-Path $manager 'update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try{$j=Get-Content -LiteralPath (Join-Path $manager 'journal.json') -Raw|ConvertFrom-Json;if($j.status -notin @('complete','pending')){throw 'There is no completed update to roll back.'};Restore-Transaction $Root $j; 'Previous app restored. Browser profiles and current save progress were not overwritten.'}finally{$lock.Dispose()}
}
