param([string]$Root = ([IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))))
$ErrorActionPreference='Stop'
try {
    $Root=[IO.Path]::GetFullPath($Root).TrimEnd('\')
    $manager=Join-Path $Root 'Setup\Updater'
    $state=Get-Content -LiteralPath (Join-Path $manager 'active.json') -Raw|ConvertFrom-Json
    if($state.application -ne 'cross-road-windows' -or $state.schema -ne 1 -or $state.version -notmatch '^\d+\.\d+\.\d+$'){throw 'Invalid Cross Road updater receipt.'}
    $files=@($state.files);if($files.Count -ne 5){throw 'Incomplete app receipt.'};$seen=@{}
    foreach($f in $files){if($f.path -cnotin @('Core.ps1','UI.ps1','Browser.ps1','version.json','README.txt') -or $seen.ContainsKey($f.path) -or $f.sha256 -notmatch '^[0-9a-f]{64}$'){throw 'Invalid app ownership receipt.'};$seen[$f.path]=$true}
    $dir=Join-Path $manager ('Versions\'+$state.version)
    foreach($f in $state.files){if($f.path -cnotin @('Core.ps1','UI.ps1','Browser.ps1','version.json','README.txt')){throw 'Unexpected app file.'};$path=Join-Path $dir $f.path;if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $f.sha256){throw 'Cross Road app file is incomplete or modified. Reinstall the verified updater bootstrap; keep profiles and Content intact.'}}
    . (Join-Path $dir 'Core.ps1')
    Repair-PendingUpdate $Root|Out-Null
    # Recovery may change the active app version; load its verified UI again.
    $state=Read-State $Root;$dir=Get-SafePath $manager ('Versions/'+$state.version)
    foreach($f in $state.files){if((Get-Sha (Get-SafePath $dir $f.path)) -cne $f.sha256){throw 'Recovered app checksum mismatch.'}}
    . (Join-Path $dir 'UI.ps1')
    Show-CrossRoadManager $Root
} catch {
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show($_.Exception.Message,'Cross Road - Recovery required')|Out-Null
    exit 1
}
