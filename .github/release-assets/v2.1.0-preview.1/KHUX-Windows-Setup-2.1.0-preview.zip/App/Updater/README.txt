Cross Road desktop package 2.1.0 - LOCAL PREVIEW, NOT PUBLISHED

Play game starts the preserved local game in its dedicated Chrome or Edge profile.
Check for updates contacts only qqCLUTCHYqq/khux-theater-tracker stable GitHub releases.
Read release details, close the game, then choose Update explicitly.
The dedicated game browser must exit fully. Edge background processes can keep
the copied/game profile open after its window closes; the updater blocks rather
than copying an open profile. Personal browser windows are not closed by it.
Updates do not install/update browsers, replace owned Content, move the game URL,
clear browser storage, migrate saves, add services, or schedule background checks.

Before applying an update, the manager checks that the game is closed, validates
release SHA256 digests, ZIP contents and per-file hashes, then backs up both known
game browser profiles plus the current runtime/app. Content is hashed and retained
in place because update packages are not permitted to write into Content.

Backups remain private under Setup/Updater/Backups. Keep them until you choose to
remove them. Rollback restores previous program/runtime files; it never rewinds
current profiles or saved progress. Restore profile backups manually only after
closing every game window and separately preserving the current profile.
Profile backup copying, hashing and enumeration support long Windows paths at
the application level; no Windows policies or system settings are changed.

Runtime updates require an explicit compatible-save contract and known previous
runtime hashes. Modified/unknown game files are preserved and block runtime updates.
Interrupted commits are recovered before Play is enabled on the next launcher run.
No release notes, manifest instructions, or archive scripts are executed as hooks.

Existing 2.0.1 users need one updater-bootstrap installation. The original desktop
shortcut is backed up and only a verified shortcut for this same game is retargeted.
Fresh/unknown shortcuts are left intact; a separate Cross Road Updates shortcut is
created. GameProfile, EdgeGameProfile, Content, Browser, and game file address stay
where they are. Existing Edge browser-choice.json remains pinned.

The public latest release is presently 2.0.1 and has no updater manifest. Release
publishing must attach CrossRoad-Update.zip and CrossRoad-Update.json with GitHub
SHA256 digests. No updater-compatible release or local audio candidate is published
by this build. The staged audio experiment is deliberately excluded.
