param([switch]$Recovery)
$repairRequested=$Recovery
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Bootstrap.ps1') -LibraryOnly
Add-Type -AssemblyName System.Windows.Forms
$picker=New-Object Windows.Forms.FolderBrowserDialog;$picker.Description='Select your existing KINGDOM HEARTS UX + Dark Road game folder (contains v1 and Content). No game will be launched.';$picker.ShowNewFolderButton=$false;$picker.SelectedPath=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'KHUX-Preservation'
try{
    if($picker.ShowDialog() -ne 'OK'){return}
    $result=Install-CrossRoadManager $picker.SelectedPath ([Environment]::GetFolderPath('Desktop')) -Recovery:$repairRequested
    [Windows.Forms.MessageBox]::Show("Cross Road updater $($result.Version) is installed.`r`n`r`nUse the desktop shortcut to open its Play / Check for Updates panel. No game was launched; saves, browser choice and Content are unchanged.`r`n`r`nShortcut: $($result.Shortcut)",'Cross Road')|Out-Null
}catch{[Windows.Forms.MessageBox]::Show($_.Exception.Message,'Updater installation stopped')|Out-Null}finally{$picker.Dispose()}
