param([string]$InstallRoot,[string]$DesktopPath=[Environment]::GetFolderPath('Desktop'),[switch]$NoShortcut,[switch]$LibraryOnly)
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Core.ps1')
function Install-CrossRoadManager([string]$Root,[string]$Desktop,[switch]$SkipShortcut,[scriptblock]$Processes,[switch]$Recovery,[scriptblock]$Fault) {
    $Root=Get-ManagerRoot $Root
    Assert-NotRunning $Root $Processes
    $manager=Join-Path $Root 'Setup\Updater';[IO.Directory]::CreateDirectory($manager)|Out-Null
    $lock=[IO.File]::Open((Join-Path $manager 'update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $prior=$null;$activated=$false
    try {
        $meta=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'version.json') -Raw|ConvertFrom-Json
        if($meta.application -ne 'cross-road-windows' -or $meta.schema -ne 1){throw 'Invalid bootstrap identity.'}
        $version=$meta.version;Get-VersionNumber $version|Out-Null;$dir=Get-SafePath $manager ('Versions/'+$version)
        $prior=$null;$recoveryBackup=$null
        if(Test-Path -LiteralPath (Join-Path $manager 'active.json')){
            Repair-PendingUpdate $Root $Processes -LockHeld|Out-Null
            $existing=Read-State $Root
            if($existing.version -cne $version){
                if(!$Recovery){throw 'An updater is already installed. Use the recovery package and REPAIR LAUNCHER.cmd for a manual preview upgrade; the stable update check does not discover previews.'}
                if((Get-VersionNumber $version) -le (Get-VersionNumber $existing.version)){throw 'Recovery will not downgrade or replace the same installed version.'}
                $prior=$existing
                foreach($f in $existing.files){$oldFile=Get-SafePath $manager ('Versions/'+$existing.version+'/'+$f.path);if((Get-Sha $oldFile) -cne $f.sha256){throw 'Installed app files were modified. They were preserved; keep profiles and Content intact.'}}
            }
        }
        $files=@()
        foreach($name in $script:UpdaterFiles){$src=Join-Path $PSScriptRoot $name;if(!(Test-Path -LiteralPath $src)){throw "Bootstrap support file missing: $name"};$files+=@{path=$name;sha256=Get-Sha $src;size=(Get-Item -LiteralPath $src).Length}}
        # Stage all five known app files before activating anything. Game/runtime/profile files are never copied here.
        [IO.Directory]::CreateDirectory($dir)|Out-Null
        foreach($f in $files){$target=Get-SafePath $dir $f.path;if(Test-Path -LiteralPath $target){if((Get-Sha $target) -cne $f.sha256){throw 'Existing app files differ; they were preserved.'}}else{Copy-Item -LiteralPath (Join-Path $PSScriptRoot $f.path) -Destination $target}}
        $starter=Join-Path $manager 'Start.ps1';if(Test-Path -LiteralPath $starter){if((Get-Sha $starter) -cne (Get-Sha (Join-Path $PSScriptRoot 'Start.ps1'))){throw 'Existing updater starter differs; it has been preserved.'}}else{Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Start.ps1') -Destination $starter}
        if($prior){
            $recoveryBackup=Get-SafePath $manager ('BootstrapBackups/'+[Guid]::NewGuid().ToString('N'))
            foreach($f in $prior.files){$saved=Get-SafePath $recoveryBackup ('Updater/'+$f.path);Copy-LongFile -LiteralPath (Get-SafePath $manager ('Versions/'+$prior.version+'/'+$f.path)) -Destination $saved;if((Get-Sha $saved) -cne $f.sha256){throw 'Previous app backup checksum mismatch. Recovery has not activated.'}}
            Write-AtomicJson (Join-Path $recoveryBackup 'active.json') $prior
        }
        if($Fault){& $Fault 'before-activation'}
        Write-AtomicJson (Join-Path $manager 'active.json') @{schema=1;application='cross-road-windows';version=$version;files=$files;installed=(Get-Date).ToUniversalTime().ToString('o');channel='preview'}
        $activated=$true
        if($Fault){& $Fault 'after-activation'}
        $shortcutPath=$null
        if(!$SkipShortcut){
            Assert-NoLinks $Desktop;[IO.Directory]::CreateDirectory($Desktop)|Out-Null
            $shortcutPath=Join-Path $Desktop 'KINGDOM HEARTS UX + Dark Road.lnk'
            $shell=New-Object -ComObject WScript.Shell
            if(Test-Path -LiteralPath $shortcutPath){
                $old=$shell.CreateShortcut($shortcutPath)
                $belongs=($old.WorkingDirectory -ieq $Root) -and (($old.TargetPath -ieq (Join-Path $Root 'Browser\chrome-win64\chrome.exe')) -or ($old.Arguments.Contains((Join-Path $Root 'Launch-KHUX.ps1'))) -or ($old.Arguments.Contains((Join-Path $Root 'v1\index.html'))) -or ($old.Arguments.Contains((Join-Path $manager 'Start.ps1'))))
                if($belongs){$backup=Get-SafePath $manager ('Migration/'+[Guid]::NewGuid().ToString('N'));[IO.Directory]::CreateDirectory($backup)|Out-Null;Copy-Item -LiteralPath $shortcutPath -Destination (Join-Path $backup 'desktop-original.lnk')}else{
                    $shortcutPath=Join-Path $Desktop 'Cross Road Updates.lnk'
                    if(Test-Path -LiteralPath $shortcutPath){$other=$shell.CreateShortcut($shortcutPath);if($other.WorkingDirectory -ine $Root -or !$other.Arguments.Contains((Join-Path $manager 'Start.ps1'))){throw 'A separate unrelated updater shortcut already exists; it was preserved.'}}
                }
            }
            $link=$shell.CreateShortcut($shortcutPath);$link.TargetPath=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe';$link.Arguments='-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "'+(Join-Path $manager 'Start.ps1')+'" -Root "'+$Root+'"';$link.WorkingDirectory=$Root;$link.Save()
            Write-AtomicJson (Join-Path $manager 'migration.json') @{shortcut=$shortcutPath;root=$Root;version=$version;gameLaunched=$false}
        }
        if($prior){Write-AtomicJson (Join-Path $manager 'bootstrap-recovery.json') @{status='complete';fromVersion=$prior.version;toVersion=$version;backup=$recoveryBackup;profilesModified=$false;runtimeModified=$false}}
        [pscustomobject]@{Version=$version;Root=$Root;Shortcut=$shortcutPath;RecoveryBackup=$recoveryBackup;ProfilesModified=$false;GameLaunched=$false}
    } catch {if($prior -and $activated){Write-AtomicJson (Join-Path $manager 'active.json') $prior};throw} finally {$lock.Dispose()}
}
if($LibraryOnly){return}
if(!$InstallRoot){throw 'Choose the existing game installation folder with -InstallRoot. The game will not be launched.'}
Install-CrossRoadManager $InstallRoot $DesktopPath -SkipShortcut:$NoShortcut
