Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
function Get-CrossRoadReleaseMessage($Offer) {
    if($Offer.Available){return "Version $($Offer.Version) is ready. Choose Update to install."}
    if(!$Offer.Compatible){return "Desktop $($Offer.Current) is installed. No compatible stable update is available. Preview fixes use a manual recovery package; Play remains available."}
    'No newer compatible stable update is available. Play remains available.'
}
function Invoke-CrossRoadGameLaunch([string]$Root,[scriptblock]$Selector,[scriptblock]$Launcher,[scriptblock]$Processes) {
    $Root=Get-ManagerRoot $Root;Repair-PendingUpdate $Root $Processes|Out-Null
    $lock=[IO.File]::Open((Join-Path $Root 'Setup\Updater\update.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try{
        if($Selector){$selected=& $Selector $Root}else{. (Join-Path $PSScriptRoot 'Browser.ps1') -NoLaunch;$selected=Get-KhuxBrowser $Root}
        if($selected.ProfileName -cnotin @('GameProfile','EdgeGameProfile')){throw 'Unexpected game profile selection.'}
        $profile=Get-SafePath $Root $selected.ProfileName;$index=Get-SafePath $Root 'v1/index.html'
        if(!(Test-Path -LiteralPath $selected.Path -PathType Leaf)){throw 'The selected browser executable is missing. Existing saves were preserved.'}
        $choice=Join-Path $Root 'browser-choice.json';if($selected.ProfileName -eq 'EdgeGameProfile' -and !(Test-Path -LiteralPath $choice)){Write-AtomicJson $choice @{browser='edge'}}
        $launchArguments='--user-data-dir="'+$profile+'" --no-first-run --no-default-browser-check --app="'+([uri]$index).AbsoluteUri+'"'
        if($Launcher){& $Launcher $selected.Path $launchArguments|Out-Null}else{Start-Process -FilePath $selected.Path -ArgumentList $launchArguments -ErrorAction Stop}
        [pscustomobject]@{Browser=$selected.Kind;Profile=$selected.ProfileName;Message="Game launch requested using $($selected.Kind)."}
    }finally{$lock.Dispose()}
}
function New-CrossRoadForm([string]$Root,[string]$Version,[type]$FormType=[Windows.Forms.Form]) {
    $form=[Activator]::CreateInstance($FormType);$form.Text='Cross Road';$form.ClientSize=New-Object Drawing.Size(760,550);$form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false;$form.AutoScaleMode='None';$form.BackColor=[Drawing.Color]::FromArgb(15,24,38);$form.ForeColor=[Drawing.Color]::White;$form.Font=New-Object Drawing.Font('Segoe UI',10)
    $title=New-Object Windows.Forms.Label;$title.Text='CROSS ROAD';$title.Font=New-Object Drawing.Font('Segoe UI',24,[Drawing.FontStyle]::Bold);$title.SetBounds(28,24,680,48);$form.Controls.Add($title)
    $versionLabel=New-Object Windows.Forms.Label;$versionLabel.Name='version';$versionLabel.Text="Desktop package $Version  |  Union chi Theater + Dark Road";$versionLabel.ForeColor=[Drawing.Color]::LightGray;$versionLabel.SetBounds(30,79,690,28);$form.Controls.Add($versionLabel)
    $status=New-Object Windows.Forms.Label;$status.Name='status';$status.Text='Ready. Check for updates whenever you want.';$status.SetBounds(30,125,690,52);$form.Controls.Add($status)
    $notes=New-Object Windows.Forms.TextBox;$notes.Name='notes';$notes.Multiline=$true;$notes.ReadOnly=$true;$notes.ScrollBars='Vertical';$notes.BackColor=[Drawing.Color]::FromArgb(24,37,54);$notes.ForeColor=[Drawing.Color]::White;$notes.BorderStyle='FixedSingle';$notes.SetBounds(30,185,700,220);$notes.Text="Updates are downloaded only after you choose Update.`r`n`r`nYour browser profiles and saves are backed up first. Owned Content is never replaced. The game stays at its original file address.`r`n`r`nBrowser updates are handled separately by Chrome or Edge.";$form.Controls.Add($notes)
    $buttons=@{}
    foreach($spec in @(@('play','Play game',30,170),@('check','Check for updates',214,170),@('update','Update',398,145),@('rollback','Restore previous app',557,173))){$b=New-Object Windows.Forms.Button;$b.Name=$spec[0];$b.Text=$spec[1];$b.SetBounds($spec[2],429,$spec[3],42);$b.FlatStyle='Flat';$b.BackColor=[Drawing.Color]::FromArgb(33,79,105);$b.ForeColor=[Drawing.Color]::White;$form.Controls.Add($b);$buttons[$spec[0]]=$b}
    $buttons.update.Enabled=$false;$buttons.update.BackColor=[Drawing.Color]::FromArgb(111,122,135);$buttons.rollback.Enabled=$false;$buttons.rollback.BackColor=[Drawing.Color]::FromArgb(111,122,135)
    $footer=New-Object Windows.Forms.Label;$footer.Text='Updates happen only when you choose Update. Close the game first; your saves stay safe.';$footer.ForeColor=[Drawing.Color]::LightGray;$footer.SetBounds(30,492,700,35);$form.Controls.Add($footer)
    [pscustomobject]@{Form=$form;Status=$status;Notes=$notes;Version=$versionLabel;Buttons=$buttons}
}
function Show-CrossRoadManager([string]$Root,[scriptblock]$LaunchSelector,[scriptblock]$ProcessLauncher,[scriptblock]$Processes) {
    $Root=Get-ManagerRoot $Root;$state=Read-State $Root;$ui=New-CrossRoadForm $Root $state.version
    $ctx=@{Offer=$null;Job=$null;Handle=$null;Kind='';Busy=$false;RestartRequired=$false;CanRollback=$false;Progress=[hashtable]::Synchronized(@{Text=''})}
    $rollback=Get-RollbackEligibility $Root;$ctx.CanRollback=$rollback.Available;$ui.Buttons.rollback.Enabled=$ctx.CanRollback;$ui.Notes.AppendText("`r`n`r`n"+$rollback.Reason+"`r`n`r`nPreview builds are installed manually. Check for updates checks the stable release channel.")
    $core=Join-Path $PSScriptRoot 'Core.ps1';$browser=Join-Path $PSScriptRoot 'Browser.ps1'
    $begin={param($kind)
        if($ctx.Busy){return};$ctx.Busy=$true;$ctx.Kind=$kind;$ctx.Progress.Text=if($kind -eq 'check'){'Checking the stable release...'}elseif($kind -eq 'update'){'Preparing update...'}else{'Restoring the previous app...'}
        foreach($b in $ui.Buttons.Values){$b.Enabled=$false;$b.BackColor=[Drawing.Color]::FromArgb(111,122,135)};$ui.Status.Text=$ctx.Progress.Text
        $ctx.Job=[PowerShell]::Create()
        $ctx.Job.AddScript({param($corePath,$root,$kind,$offer,$progress) . $corePath; $report={param($text) $progress.Text=$text};if($kind -eq 'check'){Get-LatestRelease $root}elseif($kind -eq 'update'){Install-ReleaseUpdate $root $offer $null $report}else{Restore-PreviousUpdate $root}}).AddArgument($core).AddArgument($Root).AddArgument($kind).AddArgument($ctx.Offer).AddArgument($ctx.Progress)|Out-Null
        $ctx.Handle=$ctx.Job.BeginInvoke()
    }.GetNewClosure()
    $ui.Buttons.check.Add_Click({& $begin 'check'}.GetNewClosure())
    $ui.Buttons.update.Add_Click({if([Windows.Forms.MessageBox]::Show($ui.Form,"Install desktop package $($ctx.Offer.Version)?`r`n`r`nClose the game first. A full profile/save backup will be created. Content and browser binaries will not be replaced.",'Update Cross Road','YesNo','Question') -eq 'Yes'){& $begin 'update'}}.GetNewClosure())
    $ui.Buttons.rollback.Add_Click({if([Windows.Forms.MessageBox]::Show($ui.Form,'Restore the previous app/runtime? Current browser profiles and saved progress will stay untouched.','Restore previous app','YesNo','Question') -eq 'Yes'){& $begin 'rollback'}}.GetNewClosure())
    $ui.Buttons.play.Add_Click({try{
        if($ctx.Busy){return};$launch=Invoke-CrossRoadGameLaunch $Root $LaunchSelector $ProcessLauncher $Processes;$ui.Status.Text=$launch.Message
    }catch{$ui.Status.Text='Game could not start. Details are shown below.';$ui.Notes.Text="Play error:`r`n$($_.Exception.Message)`r`n`r`nSelected installation:`r`n$Root`r`n`r`nPlay does not require an update or restore. Copy this error message when asking for help."}}.GetNewClosure())
    $timer=New-Object Windows.Forms.Timer;$timer.Interval=150
    $timer.Add_Tick({
        if(!$ctx.Busy){return};$ui.Status.Text=$ctx.Progress.Text
        if($ctx.Handle.IsCompleted){
            try{$result=@($ctx.Job.EndInvoke($ctx.Handle));if($ctx.Job.Streams.Error.Count){throw $ctx.Job.Streams.Error[0]};if($ctx.Kind -eq 'check'){$ctx.Offer=$result[-1];$ui.Notes.Text="Stable release $($ctx.Offer.Version)`r`n$($ctx.Offer.Url)`r`n`r`n$($ctx.Offer.Notes)`r`n`r`n$($rollback.Reason)`r`n`r`nPreview fixes are installed with the manual recovery package.";$ui.Status.Text=Get-CrossRoadReleaseMessage $ctx.Offer}else{$ui.Status.Text=if($ctx.Kind -eq 'update'){'Update installed. Close and reopen this launcher. No game was launched.'}else{[string]$result[-1]};$ctx.Offer=$null;$ctx.RestartRequired=$true}}catch{$ui.Status.Text=$_.Exception.Message}
            finally{$ctx.Job.Dispose();$ctx.Job=$null;$ctx.Busy=$false;foreach($b in $ui.Buttons.Values){$b.Enabled=(!$ctx.RestartRequired)};$ui.Buttons.update.Enabled=(!$ctx.RestartRequired -and $null -ne $ctx.Offer -and $ctx.Offer.Available);$ui.Buttons.rollback.Enabled=(!$ctx.RestartRequired -and $ctx.CanRollback);foreach($b in $ui.Buttons.Values){$b.BackColor=if($b.Enabled){[Drawing.Color]::FromArgb(33,79,105)}else{[Drawing.Color]::FromArgb(111,122,135)}}}
        }
    }.GetNewClosure())
    $ui.Form.Add_FormClosing({param($sender,$event) if($ctx.Busy){$event.Cancel=$true;$ui.Status.Text='Wait for the safe update/backup step to finish before closing.'}}.GetNewClosure())
    $timer.Start();try{[void]$ui.Form.ShowDialog()}finally{$timer.Stop();$timer.Dispose();$ui.Form.Dispose()}
}
