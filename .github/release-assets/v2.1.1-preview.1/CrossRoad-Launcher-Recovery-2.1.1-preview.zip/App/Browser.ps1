param([switch]$NoLaunch, [switch]$Describe)
$ErrorActionPreference = 'Stop'
function Test-KhuxProfileVersion([version]$BrowserVersion, [version]$ProfileVersion) {
    return $BrowserVersion -ge $ProfileVersion
}
function Get-KhuxInstalledCandidates([string]$Browser) {
    $exe=if($Browser -eq 'edge'){'msedge.exe'}else{'chrome.exe'}
    $relative=if($Browser -eq 'edge'){'Microsoft\Edge\Application\msedge.exe'}else{'Google\Chrome\Application\chrome.exe'}
    $candidates=@()
    foreach($key in @("HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths\$exe","HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths\$exe","HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\$exe")){
        try{$value=(Get-Item -LiteralPath $key -ErrorAction Stop).GetValue('');if($value){$candidates+=[Environment]::ExpandEnvironmentVariables($value.Trim('"'))}}catch{}
    }
    foreach($folder in @($env:ProgramFiles,${env:ProgramFiles(x86)},$env:LOCALAPPDATA)){if($folder){$candidates+=Join-Path $folder $relative}}
    $candidates|Select-Object -Unique
}
function Test-KhuxExistingProfile([string]$Root,[string]$Name) {
    $path=Join-Path $Root $Name
    if(!(Test-Path -LiteralPath $path -PathType Container)){return $false}
    if((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked game profiles are not supported. Existing saves were preserved.'}
    @((Get-ChildItem -LiteralPath $path -File -Recurse -Force -ErrorAction Stop|Select-Object -First 1)).Count -gt 0
}
function Get-KhuxEdge([string]$Root) {
    $profile = Join-Path $Root 'EdgeGameProfile'
    $minimum = [version]'0.0.0.0'
    $lastVersion = Join-Path $profile 'Last Version'
    if (Test-Path -LiteralPath $lastVersion) {
        if (![version]::TryParse(([IO.File]::ReadAllText($lastVersion)).Trim(), [ref]$minimum)) { throw 'Cannot verify the Edge game profile version.' }
    }
    foreach ($candidate in @(Get-KhuxInstalledCandidates 'edge')) {
        if (!(Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        $file=Get-Item -LiteralPath $candidate
        $match=[regex]::Match([string]$file.VersionInfo.ProductVersion,'\d+\.\d+\.\d+\.\d+')
        $signature=Get-AuthenticodeSignature -LiteralPath $candidate
        if (!$match.Success -or $file.VersionInfo.ProductName -ne 'Microsoft Edge' -or $signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'O=Microsoft Corporation') { continue }
        $version=[version]$match.Value
        if (Test-KhuxProfileVersion $version $minimum) {
            return [pscustomobject]@{Path=$candidate;Kind='Installed Microsoft Edge';Version=$version.ToString();ProfileVersion=$minimum.ToString();ProfileName='EdgeGameProfile';OlderCandidates=@()}
        }
    }
    throw "The selected Edge game profile requires Microsoft Edge $minimum or newer. Update Microsoft Edge, then try Play again. Your existing profile was preserved."
}
function Get-KhuxBrowser([string]$Root) {
    $configPath=Join-Path $Root 'browser-choice.json'
    $chosen=$null
    if(Test-Path -LiteralPath $configPath){
        $config=Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
        if($config.browser -eq 'edge'){return Get-KhuxEdge $Root}
        if($config.browser -ne 'chrome'){throw 'Unknown saved browser choice. No profile was opened.'}
        $chosen='chrome'
    }else{
        $hasChrome=Test-KhuxExistingProfile $Root 'GameProfile';$hasEdge=Test-KhuxExistingProfile $Root 'EdgeGameProfile'
        if($hasChrome -and $hasEdge){throw 'Both Chrome and Edge game profiles exist but no browser choice is saved. Choose the original browser with support before opening either profile. Existing saves were preserved.'}
        if($hasEdge){return Get-KhuxEdge $Root}
        if($hasChrome){$chosen='chrome'}
    }
    $profile = Join-Path $Root 'GameProfile'
    $minimum = [version]'0.0.0.0'
    $lastVersion = Join-Path $profile 'Last Version'
    if (Test-Path -LiteralPath $lastVersion) {
        $text = ([IO.File]::ReadAllText($lastVersion)).Trim()
        if (![version]::TryParse($text, [ref]$minimum)) { throw 'Cannot verify the existing game profile version. No browser was started.' }
    }
    $candidates = @(Get-KhuxInstalledCandidates 'chrome')
    $older = @()
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (!(Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
        $file = Get-Item -LiteralPath $candidate
        $match = [regex]::Match([string]$file.VersionInfo.ProductVersion, '\d+\.\d+\.\d+\.\d+')
        if (!$match.Success -or $file.VersionInfo.ProductName -ne 'Google Chrome') { continue }
        $signature = Get-AuthenticodeSignature -LiteralPath $candidate
        if ($signature.Status -ne 'Valid' -or $signature.SignerCertificate.Subject -notmatch 'O=Google (LLC|Inc)') { continue }
        $version = [version]$match.Value
        if (Test-KhuxProfileVersion $version $minimum) {
            return [pscustomobject]@{ Path=$candidate; Kind='Installed Chrome'; Version=$version.ToString(); ProfileVersion=$minimum.ToString(); ProfileName='GameProfile'; OlderCandidates=$older }
        }
        $older += $candidate
    }
    if(!$chosen){
        try{return Get-KhuxEdge $Root}catch{}
    }
    $bundled = Join-Path $Root 'Browser\chrome-win64\chrome.exe'
    if (Test-Path -LiteralPath $bundled -PathType Leaf) {
        $version = [version](Get-Item -LiteralPath $bundled).VersionInfo.ProductVersion
        if (Test-KhuxProfileVersion $version $minimum) {
            return [pscustomobject]@{Path=$bundled; Kind='Bundled Chrome for Testing'; Version=$version.ToString(); ProfileVersion=$minimum.ToString(); ProfileName='GameProfile'; OlderCandidates=$older}
        }
    }
    throw "Install current Google Chrome from https://www.google.com/chrome/ and launch again. This game profile requires Chrome $minimum or newer. Existing saves have not been changed."
}
if ($NoLaunch) { return }
try {
    $selected = Get-KhuxBrowser $PSScriptRoot
    if ($Describe) { $selected | ConvertTo-Json; return }
    $profile = Join-Path $PSScriptRoot $selected.ProfileName
    $configPath=Join-Path $PSScriptRoot 'browser-choice.json'
    if($selected.ProfileName -eq 'EdgeGameProfile' -and !(Test-Path -LiteralPath $configPath)){
        [IO.File]::WriteAllText($configPath,'{"browser":"edge"}',[Text.UTF8Encoding]::new($false))
    }
    $index = Join-Path $PSScriptRoot 'v1\index.html'
    if (!(Test-Path -LiteralPath $index)) { throw 'The game page is missing. Keep the launcher beside the v1, Content, and Browser folders.' }
    $arguments = '--user-data-dir="' + $profile + '" --no-first-run --no-default-browser-check --app="' + ([Uri]$index).AbsoluteUri + '"'
    Start-Process -FilePath $selected.Path -ArgumentList $arguments
} catch {
    if ($Host.Name -eq 'ConsoleHost') { Write-Error $_.Exception.Message -ErrorAction Continue }
    Add-Type -AssemblyName PresentationFramework
    [Windows.MessageBox]::Show($_.Exception.Message, 'KINGDOM HEARTS UX + Dark Road') | Out-Null
    exit 1
}
