Cross Road launcher recovery 2.1.1 - STAGED PREVIEW, NOT PUBLISHED

Close the game, extract this archive, and run REPAIR LAUNCHER.cmd. Select the
EXISTING game installation containing v1/index.html and Content, rather than
this extracted recovery package or your browser profile folder.

This explicit recovery upgrades the launcher side by side and backs up the
previous verified app files and receipt under Setup/Updater/BootstrapBackups.
It leaves v1/index.html, Content, GameProfile, EdgeGameProfile, browser choice
and save data in place. It does not launch the game or install a browser.
Modified app files, pending recovery failures and downgrades are rejected.

Play does not require Update or Restore. Check for updates still checks stable
GitHub releases; it does not discover preview builds. Restore becomes available
after a completed in-app update for the installed version. A manual launcher
recovery does not pretend a full app/runtime rollback is available.

If Play fails, copy its full error and selected installation from the details
area. Your browser must meet the existing dedicated profile's version requirement.
No audio patch, game assets, browser binaries, profiles or private logs are included.