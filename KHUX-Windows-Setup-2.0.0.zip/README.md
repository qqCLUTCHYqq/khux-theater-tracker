# KINGDOM HEARTS UX + Dark Road — optimized Windows setup 2.0.0

This continues the existing KHUX 5.0.1 WW browser preservation installer. It installs the same archived v1 HTML and Content files, uses the same GameProfile directory, and keeps the existing desktop shortcut. It contains no game files.

1. Extract the entire ZIP into a folder.
2. Double-click **START SETUP.vbs**, or **START SETUP.cmd**.
3. Setup shows download speed, estimated remaining download time, and extraction progress. Use **Pause setup** to stop safely; run setup again to resume.
4. Open **KINGDOM HEARTS UX + Dark Road**. On the first run, choose the installed **Content** folder as described in FIRST RUN.txt. On later visits, use the same shortcut and the game's Start button when shown.

Default installation: `%LOCALAPPDATA%\KHUX-Preservation`.

The setup first verifies existing files. It can reuse `%USERPROFILE%\Downloads\Content.zip` when it matches the reference hash. Complete verified content needs no ZIP download or re-extraction. An existing file that differs is preserved and stops setup; test in a separate folder in that case.

Downloads use Internet Archive's own US storage servers, with fallback to the original archive URL. The downloader starts with one connection, tests two and four, and reduces the limit when additional connections do not help or retries occur. Chunks and incomplete byte prefixes survive pauses and failures. Unsupported ranges trigger a single-connection fallback. Servers that cannot resume require restarting their single stream; old bytes are kept separately.

SHA256 pins for the game files were computed from files that match Internet Archive's published SHA1 references. See the accompanying optimization report for provenance. Chrome comes from Google's official Chrome for Testing manifest and HTTPS storage. Its ZIP is checked against Google's MD5 storage header when present; the manifest supplies no independent SHA256.

Browser profiles, imported game data, save files, and existing shortcuts are preserved. This setup does not repair or replace modified game files. The existing save/editor guide is included unchanged.

Allow at least 10 GB free for downloads/extraction. A fully verified existing installation does not need this reserve. Resume chunks are retained, including after a successful download. Corrupt data is quarantined instead of deleted, so repeated failures can require more space. Logs are saved in `Downloads\setup.log` beneath the installation folder.

Windows PowerShell 5.1, .NET Framework, and Windows Script Host are used; no Python or developer tools are needed. Script-host restrictions on managed PCs can prevent the VBS launcher; START SETUP.cmd uses the same launcher. In that case, an administrator can run Install-KHUX.ps1 with Windows PowerShell using the organization's approved policy.

For an isolated test, run Install-KHUX.ps1 with `-InstallRoot <test-folder> -DesktopPath <test-shortcut-folder> -NoLaunch`. `-Headless` provides diagnostic text output.

Release 2.0.0 — October 8, 2026. Published through the existing Theater Tracker GitHub Pages distribution. The original installer remains available separately as a rollback.
