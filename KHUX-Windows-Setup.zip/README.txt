﻿KINGDOM HEARTS UX + Dark Road - Browser Installer 2.0.1

1. Right-click the ZIP and choose Extract All.
2. Double-click START SETUP.cmd. Keep the App folder beside it.
3. Let setup finish. Pause safely at any time; run START SETUP.cmd again to resume.
4. Click Launch Game. The existing desktop shortcut also works.

FIRST LAUNCH
Click Copy Content folder path in setup. In the game click Game folder / Choose
Files, paste the path in the folder picker's address bar, select that Content
folder and confirm Upload / Select Folder. This imports files locally. Wait for
the title screen. Later launches use the same shortcut and cached browser data.
Already imported? Click Start. Do not choose Change Game Files or Clear Storage.

SAVE BACKUP / RESTORE
Use the completion screen's Save backup / restore guide button. Instructions also
remain in %LOCALAPPDATA%\KHUX-Preservation\Setup\Instructions.txt.
Close Chrome fully before copying the ENTIRE GameProfile folder to a dated backup.
Keep the original install path. To restore, close Chrome, back up the current
profile separately, then deliberately replace it with the whole saved profile at
the same original path. Do not merge database files or clear browser storage.
Setup never replaces or moves GameProfile, game files, or existing shortcuts.

RECOVERY AND REQUIREMENTS
64-bit Windows 10/11, Windows PowerShell 5.1 and .NET Framework.
Internet is needed for installation; allow 10 GB free for downloading/extraction.
A complete verified installation does not need that reserve. Resume/quarantine
files are retained. Download errors preserve partial data. Modified existing game
files cause setup to stop safely. No administrator access normally needed.
On managed PCs, ask your administrator if script execution is restricted.
Advanced diagnostics: App\Install-KHUX.ps1 supports -Headless, -NoLaunch,
-InstallRoot, -DesktopPath, -LocalContent and -LibraryOnly as before.

Installed folders (existing locations retained):
  v1 / Content    Original archived game files
  Browser         Standalone Chrome from Google's official HTTPS distribution
  GameProfile     Persistent imported game data and saves - keep intact
  Downloads       Verified archives, partial chunks and recovery data
  Setup           Instructions, configuration receipt and Logs\setup.log
Older Downloads\setup.log and FIRST RUN.txt are preserved when present.

Downloads retain adaptive 1/2/4 connections, retries/backoff, resumable chunks,
SHA256 verification and automatic serial fallback. Sources remain the original
Internet Archive collection and its own storage replicas. Game SHA256 pins were
derived from files matching Archive SHA1 references. Google's Chrome manifest has
no SHA256; storage MD5 is checked when present and a local SHA256 receipt enables
reuse. The installer ZIP contains no game files or browser binaries.
Source: https://archive.org/details/khux-5.0.1-ww-web

CHANGES FROM 2.0.0
One obvious START SETUP.cmd entry; support files grouped in App; clearer four-step window;
completion with Launch Game, Copy Content folder path and save recovery guide;
no Windows Script Host dependency; no automatic Notepad launch; installed support/configuration/logs separated.
Downloader, game content, profile paths, file origin and shortcut behavior unchanged.
Manual first-run folder selection remains to preserve browser consent and storage.
2.0.0 remains a separate rollback ZIP. Roll back the helper, not your profile.
Unofficial preservation helper; not affiliated with Square Enix or Disney.
