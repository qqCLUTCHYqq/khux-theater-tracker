@echo off
start "" wscript.exe "%~dp0App\SETUP.vbs"
