﻿param(
    [string]$InstallRoot = (Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'KHUX-Preservation'),
    [string]$DesktopPath = [Environment]::GetFolderPath('Desktop'),
    [switch]$NoLaunch, [switch]$Headless, [switch]$LibraryOnly, [string]$UiPreviewPath,
    [string]$LocalContent = (Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads\Content.zip')
)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression.FileSystem
if (-not ('KhuxSetup.Downloader' -as [type])) { Add-Type -Path (Join-Path $PSScriptRoot 'Downloader.cs') }
$script:form = $null
$script:cancelRequested = $false
$script:logPath = $null
function Show-Status([string]$Text, [int]$Percent = -1) {
    if ($script:form) {
        $script:label.Text = $Text
        if ($Percent -ge 0) { $script:bar.Style = 'Continuous'; $script:bar.Value = [Math]::Min(100,$Percent) }
        else { $script:bar.Style = 'Marquee' }
        [Windows.Forms.Application]::DoEvents()
    } else { Write-Host $Text }
    if ($script:cancelRequested) { throw 'Setup paused. Run START SETUP.cmd again to resume.' }
}
function Write-Log([string]$Text) { if ($script:logPath) { Add-Content -LiteralPath $script:logPath -Value ((Get-Date).ToString('o') + ' ' + $Text) } }
function Download-File([string[]]$Sources,[string]$Path,[long]$Size,[string]$Sha256) {
    if ((Test-Path -LiteralPath $Path) -and $Sha256 -and ([KhuxSetup.Downloader]::Hash($Path) -eq $Sha256)) {
        Show-Status "Reusing verified $([IO.Path]::GetFileName($Path))."; return
    }
    $downloader = New-Object KhuxSetup.Downloader
    $downloader.Start($Sources,$Path,$Size,$Sha256)
    $timer = [Diagnostics.Stopwatch]::StartNew(); $lastTime = 0.0; $lastBytes = 0L; $rate = 0.0; $logged = 0
    try {
        while (-not $downloader.Done) {
            $elapsed = $timer.Elapsed.TotalSeconds
            if ($elapsed - $lastTime -ge 0.5) {
                $current = $downloader.NetworkBytes
                $instant = ($current - $lastBytes) / ($elapsed - $lastTime)
                if ($instant -gt 0) { if ($rate -eq 0) { $rate=$instant } else { $rate=.3*$instant+.7*$rate } }
                $lastTime=$elapsed; $lastBytes=$current
                $done=$downloader.Completed
                $remaining=[Math]::Max([long]0,[long]($Size-$done))
                $eta=if($rate -gt 0) { [TimeSpan]::FromSeconds($remaining/$rate).ToString('hh\:mm\:ss') } else { 'calculating' }
                $text=if($done -ge $Size) { $downloader.Status+"`r`nAll download bytes received." } else { "{0}`r`n{1:N1} / {2:N1} MB    {3:N2} MB/s    ETA {4}" -f $downloader.Status,($done/1MB),($Size/1MB),($rate/1MB),$eta }
                Show-Status $text ([int](100*$done/$Size))
            }
            if ($script:form) { [Windows.Forms.Application]::DoEvents() }
            if ($script:cancelRequested) { $downloader.Cancel() }
            Start-Sleep -Milliseconds 100
        }
    } catch { $downloader.Cancel(); throw }
    finally {
        # Wait briefly for aborted requests to flush before allowing the cache lock to close.
        while (-not $downloader.Done) { Start-Sleep -Milliseconds 100 }
        foreach($event in $downloader.Events) { Write-Log $event }
        Write-Log ("Download duration={0:N2}s networkBytes={1} retries={2} effectiveURL={3}" -f $timer.Elapsed.TotalSeconds,$downloader.NetworkBytes,$downloader.Retries,$downloader.EffectiveUrl)
    }
    if ($downloader.Error) { throw $downloader.Error }
}
function Expand-Preserved([string]$Zip,[string]$Destination,[string]$AllowedPrefix) {
    $archive=[IO.Compression.ZipFile]::OpenRead($Zip)
    $stage=Join-Path $cache ('extract-'+[Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $stage | Out-Null
    $entries=@()
    try {
        $prefix=[IO.Path]::GetFullPath($Destination).TrimEnd('\')+'\'
        foreach($entry in $archive.Entries) {
            $name=$entry.FullName.Replace('/','\')
            $target=[IO.Path]::GetFullPath((Join-Path $Destination $name))
            if (-not $target.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase) -or $name.Contains(':') -or
                -not $name.StartsWith($AllowedPrefix+'\',[StringComparison]::OrdinalIgnoreCase)) { throw "Unexpected archive path: $name" }
            if ($name.EndsWith('\')) { continue }
            $entries+=@{ Entry=$entry; Name=$name; Target=$target }
        }
        $extractBytes=[long](($entries | ForEach-Object {$_.Entry.Length} | Measure-Object -Sum).Sum)
        if([IO.DriveInfo]::new([IO.Path]::GetPathRoot([IO.Path]::GetFullPath($stage))).AvailableFreeSpace -lt ($extractBytes+200MB)) {throw 'Not enough space for safe archive extraction. Free disk space and resume setup.'}
        $n=0
        foreach($item in $entries) {
            $n++; Show-Status "Checking and extracting files ($n / $($entries.Count))." ([int](100*$n/$entries.Count))
            $staged=Join-Path $stage $item.Name
            New-Item -ItemType Directory -Force ([IO.Path]::GetDirectoryName($staged)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($item.Entry,$staged,$false)
            if ((Get-Item -LiteralPath $staged).Length -ne $item.Entry.Length) { throw "Incomplete extraction: $($item.Name)" }
            if (Test-Path -LiteralPath $item.Target) {
                if ([KhuxSetup.Downloader]::Hash($item.Target) -ne [KhuxSetup.Downloader]::Hash($staged)) {
                    throw "Existing file differs: $($item.Target). It has been preserved. Use a separate installation folder to test."
                }
            }
        }
        # Only publish missing files after every entry has passed validation. No profile paths are accepted.
        foreach($item in $entries) {
            if (-not (Test-Path -LiteralPath $item.Target)) {
                New-Item -ItemType Directory -Force ([IO.Path]::GetDirectoryName($item.Target)) | Out-Null
                Move-Item -LiteralPath (Join-Path $stage $item.Name) -Destination $item.Target
            }
        }
    } finally {
        $archive.Dispose()
        # The generated staging path is verified to be directly beneath this install's cache.
        if ([IO.Path]::GetFullPath($stage).StartsWith([IO.Path]::GetFullPath($cache).TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) {
            Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
function Ensure-Shortcut([string]$Browser,[string]$Arguments,[string]$Root,[string]$Desktop) {
    $shortcutPath=Join-Path $Desktop 'KINGDOM HEARTS UX + Dark Road.lnk'
    if (Test-Path -LiteralPath $shortcutPath) { Write-Log "Existing shortcut preserved unchanged: $shortcutPath"; return $shortcutPath }
    New-Item -ItemType Directory -Force $Desktop | Out-Null
    $shell=New-Object -ComObject WScript.Shell; $shortcut=$shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath=$Browser; $shortcut.Arguments=$Arguments; $shortcut.WorkingDirectory=$Root; $shortcut.Save()
    return $shortcutPath
}
function Test-InstalledContent([string]$Root) {
    $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Content-manifest.json') -Raw | ConvertFrom-Json
    $complete=$true; $contentRoot=[IO.Path]::GetFullPath((Join-Path $Root 'Content')).TrimEnd('\')+'\'
    foreach($file in $manifest) {
        $target=[IO.Path]::GetFullPath((Join-Path $contentRoot $file.path))
        if(-not $target.StartsWith($contentRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid content manifest path.' }
        if(-not (Test-Path -LiteralPath $target)) { $complete=$false; continue }
        Show-Status "Verifying existing $($file.path)."
        if((Get-Item -LiteralPath $target).Length -ne $file.size -or [KhuxSetup.Downloader]::Hash($target) -ne $file.sha256) {
            throw "Existing file differs: $target. It has been preserved. Use a separate installation folder to test."
        }
    }
    return $complete
}
if ($LibraryOnly) { return }
$root=[IO.Path]::GetFullPath($InstallRoot); $cache=Join-Path $root 'Downloads'
$lock=$null
try {
    if (-not $Headless) {
        Add-Type -AssemblyName System.Windows.Forms,System.Drawing
        [Windows.Forms.Application]::EnableVisualStyles()
        $script:form=New-Object Windows.Forms.Form
        $script:form.Text='KINGDOM HEARTS UX + Dark Road - Setup 2.0.1'
        $script:form.Size=New-Object Drawing.Size(680,460); $script:form.StartPosition='CenterScreen'
        $script:form.FormBorderStyle='FixedDialog'; $script:form.MaximizeBox=$false
        $script:form.BackColor=[Drawing.ColorTranslator]::FromHtml('#11121a')
        $script:form.ForeColor=[Drawing.Color]::WhiteSmoke
        $script:form.Font=New-Object Drawing.Font('Segoe UI',10)
        $title=New-Object Windows.Forms.Label; $title.SetBounds(24,20,625,40)
        $title.Text='KINGDOM HEARTS UX + Dark Road'; $title.Font=New-Object Drawing.Font('Segoe UI',20)
        $title.ForeColor=[Drawing.ColorTranslator]::FromHtml('#ebd29d')
        $script:steps=New-Object Windows.Forms.Label; $script:steps.SetBounds(26,72,620,30)
        $script:steps.Text='1 Check installation   >   2 Download   >   3 Browser   >   4 Ready'
        $script:label=New-Object Windows.Forms.Label; $script:label.SetBounds(26,120,615,160)
        $script:label.Font=New-Object Drawing.Font('Segoe UI',11)
        $script:bar=New-Object Windows.Forms.ProgressBar; $script:bar.SetBounds(26,292,615,22)
        $button=New-Object Windows.Forms.Button; $button.Text='Pause setup'; $button.SetBounds(491,340,150,38)
        $button.ForeColor=[Drawing.Color]::Black; $button.BackColor=[Drawing.ColorTranslator]::FromHtml('#ebd29d')
        $button.Add_Click({
            if($script:finished) { Start-Process -FilePath $script:launchBrowser -ArgumentList $script:launchArguments }
            else { $script:cancelRequested=$true }
        })
        $script:copyButton=New-Object Windows.Forms.Button; $script:copyButton.Text='Copy Content folder path'
        $script:copyButton.SetBounds(26,340,235,38); $script:copyButton.Visible=$false
        $script:copyButton.ForeColor=[Drawing.Color]::Black
        $script:copyButton.BackColor=[Drawing.Color]::WhiteSmoke
        $script:copyButton.Add_Click({ [Windows.Forms.Clipboard]::SetText($script:contentPath); $script:copyButton.Text='Folder path copied' })
        $script:helpButton=New-Object Windows.Forms.Button; $script:helpButton.Text='Save backup / restore guide'
        $script:helpButton.SetBounds(270,340,212,38); $script:helpButton.Visible=$false
        $script:helpButton.ForeColor=[Drawing.Color]::Black
        $script:helpButton.BackColor=[Drawing.Color]::WhiteSmoke
        $script:helpButton.Add_Click({Start-Process notepad.exe -ArgumentList ('"'+$script:guidePath+'"')})
        $script:form.Add_FormClosing({param($sender,$e) if(-not $script:finished) {$script:cancelRequested=$true;$e.Cancel=$true}})
        $script:form.Controls.AddRange(@($title,$script:steps,$script:label,$script:bar,$button,$script:copyButton,$script:helpButton)); $script:form.Show()
    }
    New-Item -ItemType Directory -Force $root,$cache | Out-Null
    try { $lock=[IO.File]::Open((Join-Path $cache 'setup.lock'),'OpenOrCreate','ReadWrite','None') }
    catch { throw 'Another setup is using this folder. Close it before running setup again.' }
    $support=Join-Path $root 'Setup'
    New-Item -ItemType Directory -Force (Join-Path $support 'Logs'),(Join-Path $support 'Config') | Out-Null
    $script:logPath=Join-Path $support 'Logs\setup.log'
    Show-Status 'Checking existing files. Browser saves and profiles are preserved.'
    $index=Join-Path $root 'v1\index.html'
    $indexHash='4b93ed828aebc6b2eb15ab49489693ae9f7db4f77d867ca1fc0b46fb57e3a539'
    if ((Test-Path -LiteralPath $index) -and [KhuxSetup.Downloader]::Hash($index) -ne $indexHash) { throw 'Existing index.html differs from the original archive. It has been preserved. Test in a separate folder.' }
    $contentReady=Test-InstalledContent $root
    $browser=Join-Path $root 'Browser\chrome-win64\chrome.exe'
    $needsFiles=-not $contentReady -or -not (Test-Path -LiteralPath $index) -or -not (Test-Path -LiteralPath $browser)
    # Space for missing files, retained chunks plus assembly, extraction, browser and a margin.
    # A verified cached Content ZIP needs extraction space but no duplicate download space.
    $requiredSpace=1GB
    if(-not $contentReady) {
        $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Content-manifest.json') -Raw | ConvertFrom-Json
        $requiredSpace += [long](($manifest | Measure-Object -Property size -Sum).Sum)
        $cached=Join-Path $cache 'Content.zip'
        if(-not(Test-Path -LiteralPath $cached) -or [KhuxSetup.Downloader]::Hash($cached) -ne 'b65eda4bafbd7a0a52cf8cf35cb77ed255cdea1cdc89a9a91850fbc28c13fdbf') {$requiredSpace += 2L*2244643150L}
    }
    if(-not(Test-Path -LiteralPath $browser)) {$requiredSpace += 1GB}
    if(-not(Test-Path -LiteralPath $index)) {$requiredSpace += 80MB}
    if($needsFiles -and [IO.DriveInfo]::new([IO.Path]::GetPathRoot($root)).AvailableFreeSpace -lt $requiredSpace) {
        throw ('Please free at least {0:N1} GB on the installation drive, then resume setup.' -f ($requiredSpace/1GB))
    }
    if($script:form) {$script:steps.Text='Step 2 of 4 - Download or reuse verified files'}
    Download-File @('https://ia601003.us.archive.org/23/items/khux-5.0.1-ww-web/v1/index.html','https://ia801003.us.archive.org/23/items/khux-5.0.1-ww-web/v1/index.html','https://archive.org/download/khux-5.0.1-ww-web/v1/index.html') $index 38803504 $indexHash
    $contentZip=Join-Path $cache 'Content.zip'
    $contentHash='b65eda4bafbd7a0a52cf8cf35cb77ed255cdea1cdc89a9a91850fbc28c13fdbf'
    if (-not $contentReady -and -not (Test-Path -LiteralPath $contentZip) -and (Test-Path -LiteralPath $LocalContent)) {
        Show-Status 'Verifying your existing Content.zip for reuse.'
        if ([KhuxSetup.Downloader]::Hash($LocalContent) -eq $contentHash) { Copy-Item -LiteralPath $LocalContent -Destination $contentZip; Write-Log 'Reused verified local Content.zip.' }
    }
    if (-not $contentReady) {
        Download-File @('https://ia601003.us.archive.org/23/items/khux-5.0.1-ww-web/Content.zip','https://ia801003.us.archive.org/23/items/khux-5.0.1-ww-web/Content.zip','https://archive.org/download/khux-5.0.1-ww-web/Content.zip') $contentZip 2244643150 $contentHash
        Expand-Preserved $contentZip $root 'Content'
        if(-not (Test-InstalledContent $root)) { throw 'Content verification did not finish.' }
    } else { Write-Log 'Verified existing content; skipped download and extraction.' }
    $content=Join-Path $root 'Content'
    foreach($name in @('main.76.com.square_enix.android_googleplay.khuxww.obb','patch.87.com.square_enix.android_googleplay.khuxww.obb','extra.mp4')) {
        if (-not (Test-Path -LiteralPath (Join-Path $content $name))) { throw "Missing archive file: $name" }
    }
    if($script:form) {$script:steps.Text='Step 3 of 4 - Prepare the offline browser'}
    if (-not (Test-Path -LiteralPath $browser)) {
        Show-Status 'Getting the official standalone Chrome browser.'
        $release=Invoke-RestMethod 'https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json' -TimeoutSec 30
        $url=($release.channels.Stable.downloads.chrome | Where-Object platform -eq 'win64').url
        if (-not $url.StartsWith('https://storage.googleapis.com/chrome-for-testing-public/')) { throw 'Unexpected browser source.' }
        $browserZip=Join-Path $cache ('chrome-'+$release.channels.Stable.version+'.zip')
        $head=Invoke-WebRequest -UseBasicParsing -Method Head -Uri $url -TimeoutSec 30
        $size=[long]($head.Headers['Content-Length'] | Select-Object -First 1)
        # Google publishes no SHA256 in this manifest. A local receipt enables repeat reuse, not publisher verification.
        $receipt=$browserZip+'.sha256'; $digest=$null
        if ((Test-Path -LiteralPath $receipt) -and (Test-Path -LiteralPath $browserZip)) { $digest=(Get-Content -LiteralPath $receipt -Raw).Trim() }
        Download-File @($url) $browserZip $size $digest
        $googleHashes=[string]$head.Headers['x-goog-hash']
        if($googleHashes -match 'md5=([A-Za-z0-9+/=]+)') {
            $expectedMd5=$Matches[1]; $hex=(Get-FileHash -LiteralPath $browserZip -Algorithm MD5).Hash
            $bytes=New-Object byte[] 16
            for($i=0;$i -lt 16;$i++) {$bytes[$i]=[Convert]::ToByte($hex.Substring($i*2,2),16)}
            if([Convert]::ToBase64String($bytes) -ne $expectedMd5) { throw 'The browser ZIP does not match Google storage metadata. No browser files were installed.' }
            Write-Log 'Browser ZIP matches the MD5 published by Google storage.'
        }
        Set-Content -LiteralPath $receipt -Value ([KhuxSetup.Downloader]::Hash($browserZip)) -NoNewline
        Expand-Preserved $browserZip (Join-Path $root 'Browser') 'chrome-win64'
    }
    if (-not (Test-Path -LiteralPath $browser)) { throw 'Chrome extraction did not finish.' }
    & icacls.exe (Join-Path $root 'Browser') /grant '*S-1-15-2-1:(OI)(CI)(RX)' '*S-1-15-2-2:(OI)(CI)(RX)' /T /Q | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Could not configure browser read access.' }
    $profile=Join-Path $root 'GameProfile'
    $arguments='--user-data-dir="'+$profile+'" --no-first-run --no-default-browser-check "'+$index+'"'
    $shortcutPath=Ensure-Shortcut $browser $arguments $root $DesktopPath
    if($script:form) {$script:steps.Text='Step 4 of 4 - Ready to play'}
    $guidePath=Join-Path $support 'Instructions.txt'
    $script:contentPath=$content; $script:guidePath=$guidePath
    $script:launchBrowser=$browser; $script:launchArguments=$arguments
    # Installer-owned support paths only; existing game/profile/shortcut paths remain unchanged.
    Set-Content -LiteralPath $guidePath -Encoding UTF8 -Value @"
KINGDOM HEARTS UX + Dark Road - Browser setup 2.0.1

FIRST LAUNCH (one folder selection)
1. Open the desktop shortcut or click Launch Game in setup.
2. Click Game folder / Choose Files in the game.
3. Select this Content folder (paste the path into the folder picker's address bar):
$content
4. Confirm Upload / Select Folder if asked. Files are imported locally.
5. Wait for the title screen. Leave the browser open until import finishes.
Later, use the same desktop shortcut and click Start when shown.
If the game already has cached files, use Start; do not change the game files.
No internet is needed after installation and the first successful import.

BACK UP SAVES
Close all game windows and let Chrome finish exiting. Copy this entire folder to a
dated backup on another drive (not just one IndexedDB file):
$profile
For a portable recovery backup, also copy the entire installation folder:
$root
Keep this original installation path: browser storage is associated with the game URL.
Do not clear browser site data, use incognito, or delete GameProfile.

RESTORE SAVES
Close the game and setup. Preserve a separate copy of the current GameProfile first.
Restore the entire backed-up GameProfile to the SAME original path shown above.
Do not merge individual database files or restore while Chrome is running.
Launch with the same desktop shortcut. Restore is a deliberate replacement of saves;
setup itself never restores or overwrites your profile.
Backups may contain private browser data. Keep them private.

RECOVERY
Run START SETUP.cmd again after a pause or failure. Verified files and download chunks are
reused. A differing existing game file stops setup and remains intact.
Logs: $script:logPath
Downloads and resume files: $cache
Browser: $browser
Source: https://archive.org/details/khux-5.0.1-ww-web
"@
    $editor=Join-Path $support 'editor-guide.html'
    if(-not(Test-Path -LiteralPath $editor)) {Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'editor-guide.html') -Destination $editor}
    @{version='2.0.1';installed=(Get-Date).ToString('o');profile=$profile;game=$index;shortcut=$shortcutPath} |
        ConvertTo-Json | Set-Content -LiteralPath (Join-Path $support 'Config\installer.json') -Encoding UTF8
    Show-Status "Setup complete. Your desktop shortcut is ready.`r`n`r`nFirst launch: choose the Content folder, confirm the browser prompt, and wait for import.`r`nAlready imported? Click Start in the game. Your saves are preserved." 100
    Write-Log 'Setup 2.0.1 complete.'
    $script:finished=$true
    if($script:form) {
        $button.Text='Launch Game'; $script:copyButton.Visible=$true; $script:helpButton.Visible=$true
        if($UiPreviewPath) {
            [Windows.Forms.Application]::DoEvents()
            $bitmap=New-Object Drawing.Bitmap($script:form.Width,$script:form.Height)
            $script:form.DrawToBitmap($bitmap,(New-Object Drawing.Rectangle(0,0,$bitmap.Width,$bitmap.Height)))
            $bitmap.Save([IO.Path]::GetFullPath($UiPreviewPath)); $bitmap.Dispose()
        } else {
            while($script:form.Visible) {[Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100}
        }
    } elseif(-not $NoLaunch) {Start-Process -FilePath $browser -ArgumentList $arguments}
} catch {
    Write-Log $_.Exception.ToString()
    $hint=if($_.Exception.Message -match 'free at least') {'Free disk space, then run setup again.'} elseif($_.Exception.Message -match 'differs') {'Keep your existing files. Use a separate folder for a clean test.'} elseif($script:cancelRequested) {'Setup is paused. Run START SETUP.cmd again to continue.'} else {'Check your internet connection and run START SETUP.cmd again. If this repeats, send the setup log for help.'}
    $message=$_.Exception.Message+"`r`n"+$hint+"`r`nExisting game files, profiles, saves, and partial downloads are preserved. Run setup again to resume.`r`nDetails: $script:logPath"
    if ($script:form) { [Windows.Forms.MessageBox]::Show($script:form,$message,'Setup stopped') | Out-Null } else { Write-Error $message -ErrorAction Continue }
    exit 1
} finally {
    if($lock) {$lock.Dispose()}
    $script:finished=$true
    if($script:form) {$script:form.Dispose()}
}
